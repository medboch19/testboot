export class Candidat {
   
	  cin:number;
	  nom:string;
	  prenom:string;
	  adresse:string;
	  telephone_personnel :number;
	  nomAdministration:string;
	  lieuTravail:string;
	  adresseTravail:string;
	  niveauAcademique :string; 
	  gradeActuel:string;
	  descriptionTaches:string;
	  dateLimiteinscription:Date ; 
	  categorie:String ;
	  adressemail:String ;
	  idGrade:number;
	  specialite:String;
	
  }
  